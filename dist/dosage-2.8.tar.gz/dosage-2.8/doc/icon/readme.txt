Source:
http://www.iconarchive.com/show/multiminimal-icons-by-multivitamin/my-pictures-icon.html
