Dosage
=======

Dosage is a comic strip downloader and archiver.

See http://wummel.github.io/dosage/ for more info.
